from django.apps import AppConfig


class SthubertConfig(AppConfig):
    name = 'sthubert'
